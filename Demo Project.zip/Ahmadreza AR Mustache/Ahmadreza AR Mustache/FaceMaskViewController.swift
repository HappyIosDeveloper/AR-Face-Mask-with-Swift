//
//  FaceMaskViewController.swift
//  Ahmadreza AR Mustache
//
//  Created by Ahmadreza on 12/2/21.
//

import UIKit
import ARKit
import SceneKit

class FaceMaskViewController: UIViewController, AVCaptureVideoDataOutputSampleBufferDelegate, ARSessionDelegate {
    
    let sceneView = ARSCNView(frame: UIScreen.main.bounds)
    var mustache = SCNNode()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.addSubview(sceneView)
        sceneView.delegate = self
        guard ARFaceTrackingConfiguration.isSupported else { return }
        let configuration = ARFaceTrackingConfiguration()
        configuration.isLightEstimationEnabled = true
        configuration.maximumNumberOfTrackedFaces = 2
        sceneView.session.run(configuration, options: [.resetTracking, .removeExistingAnchors])
    }
}

extension FaceMaskViewController: ARSCNViewDelegate {
    
    func renderer(_ renderer: SCNSceneRenderer, nodeFor anchor: ARAnchor) -> SCNNode? {
        let material = SCNMaterial()
        material.locksAmbientWithDiffuse = true
        material.isDoubleSided = false
        material.diffuse.contents = UIImage(named: "mustache2")
        guard let device = sceneView.device else { return nil }
        let faceGeometry = ARSCNFaceGeometry(device: device)
        let node = SCNNode(geometry: faceGeometry)
        node.geometry?.firstMaterial?.fillMode = .fill
        node.geometry?.materials = [material]
//        node.geometry?.firstMaterial?.diffuse.contents = UIColor.clear
        return node
    }
    
    func renderer(_ renderer: SCNSceneRenderer, didUpdate node: SCNNode, for anchor: ARAnchor) {
        guard let faceAnchor = anchor as? ARFaceAnchor, let faceGeometry = node.geometry as? ARSCNFaceGeometry else { return }
        faceGeometry.update(from: faceAnchor.geometry)
    }
}
